-   **1.4.0**

    -   Move sound effect to seperate mod [Click](https://thunderstore.io/c/lethal-company/p/l3ackStab/Minecraft_Company_Effect/)

-   **1.3.0**

    -   Added new sounds
		- BeeZap1.wav
		- BeeZap2.wav
		- FallInWater.wav
		- FlashlightMiniOutOfBatteries.wav
		- FlashlightOutOfBatteries.wav
		- Levelup.wav

-   **1.2.1**

    -   Remove some sounds

-   **1.2.0**

    -   Added new sounds
		- VoiceCry.wav
		- VoiceCry2.wav
		- WoodStep1.wav
		- WoodStep2.wav
		- WoodStep3.wav
		- WoodStep4.wav
		- BugWalk1.wav
		- BugWalk2.wav
		- BugWalk3.wav
		- BugWalk4.wav
		- Chitter1.wav
		- Chitter2.wav
		- Chitter3.wav
		- ClimbLadderStep2.wav
		- ClimbLadderStep3.wav
		- ClimbLadderStep4.wav
		- CupboardClose.wav
		- CupboardOpen.wav
		- Grass1.wav
		- Grass1_0.wav
		- Grass2.wav
		- Grass3.wav
		- grass4.wav
		- Gravel1.wav
		- Gravel2.wav
		- Gravel3.wav
		- Gravel4.wav
		- Rain.wav
		- Snow1.wav
		- Snow2.wav
		- Snow3.wav
		- Snow4.wav
		- SpiderAttack.wav
		- SpiderHit.wav
		- TakeDamage.wav
		
-   **1.1.1**

    -   Fix bug

-   **1.1.0**

	-   Added new sounds
		- BellDinger.wav
		- Creak4.wav
		- Creak7.wav
		- Night.wav
		- Thunder1.wav
		- Thunder2.wav
		- Thunder3.wav

-   **1.0.0**

    -   Mod release