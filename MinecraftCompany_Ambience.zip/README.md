## I decided to move sound effect to separate mod
[Minecraft Company Effect](https://thunderstore.io/c/lethal-company/p/l3ackStab/Minecraft_Company_Effect/)

## What Sounds Changed:
This mod replaces various ambient sounds with Minecraft alternatives.

## Example list of Replaced Sounds:
- StrangeNoise2.wav
- StrangeNoise2_0.wav
- Random1.wav
- Random2.wav
- Nervous.wav
- DarkAmbiance.wav
- BumpOutsideShip1.wav
- BumpOutsideShip2.wav
- BumpOutsideShip3.wav
- BumpOutsideShip4.wav
- BellChimeAmbience.wav
- BellDinger.wav
- Creak4.wav
- Creak7.wav
- Night.wav
- Thunder1.wav
- Thunder2.wav
- Thunder3.wav
- and many more!

